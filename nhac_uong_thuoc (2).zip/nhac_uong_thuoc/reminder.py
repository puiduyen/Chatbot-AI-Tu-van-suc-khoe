from database import get_due_medicines


def check_reminder():

    medicines = get_due_medicines()

    return medicines