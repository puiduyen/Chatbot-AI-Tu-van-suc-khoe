from flask import (
    Flask,
    render_template,
    request,
    redirect,
    url_for,
    jsonify
)

import os
from datetime import datetime

from database import (
    create_database,
    add_medicine,
    get_medicines,
    get_due_medicines,
    save_proof,
    get_medicine
)


app = Flask(__name__)


# =========================
# THƯ MỤC LƯU ẢNH
# =========================

UPLOAD_FOLDER = "static/proofs"

os.makedirs(UPLOAD_FOLDER, exist_ok=True)

app.config["UPLOAD_FOLDER"] = UPLOAD_FOLDER


# =========================
# TẠO DATABASE
# =========================

create_database()


# =========================
# TRANG CHÍNH
# =========================

@app.route("/")
def home():

    medicines = get_medicines()

    return render_template(
        "home.html",
        medicines=medicines
    )


# =========================
# THÊM LỊCH UỐNG THUỐC
# =========================

@app.route("/add", methods=["GET", "POST"])
def add():

    if request.method == "POST":

        name = request.form.get("name")
        time = request.form.get("time")
        frequency = request.form.get("frequency")

        start_date = request.form.get("start_date")
        end_date = request.form.get("end_date")

        if not name or not time:
            return "Vui lòng nhập đầy đủ tên thuốc và thời gian."

        add_medicine(
            name,
            time,
            frequency,
            start_date,
            end_date
        )

        return redirect(url_for("home"))

    return render_template(
        "add_medicine.html"
    )


# =========================
# API KIỂM TRA THUỐC ĐẾN GIỜ
# =========================

@app.route("/api/reminder")
def api_reminder():

    medicines = get_due_medicines()

    data = []

    for medicine in medicines:

        data.append({
            "id": medicine["id"],
            "name": medicine["name"],
            "time": medicine["time"],
            "frequency": medicine["frequency"],
            "proof": medicine["proof"]
        })

    return jsonify(data)


# =========================
# TRANG NHẮC UỐNG THUỐC
# =========================

@app.route("/reminder")
def reminder():

    medicines = get_due_medicines()

    return render_template(
        "reminder.html",
        medicines=medicines
    )


# =========================
# XÁC MINH BẰNG ẢNH
# =========================

@app.route("/verify/<int:medicine_id>", methods=["POST"])
def verify(medicine_id):

    medicine = get_medicine(medicine_id)

    if medicine is None:
        return jsonify({
            "success": False,
            "message": "Không tìm thấy thuốc."
        })

    photo = request.files.get("photo")

    if photo is None:
        return jsonify({
            "success": False,
            "message": "Bạn chưa chụp ảnh."
        })

    if photo.filename == "":
        return jsonify({
            "success": False,
            "message": "Ảnh không hợp lệ."
        })

    # Tạo tên file
    timestamp = datetime.now().strftime(
        "%Y%m%d_%H%M%S"
    )

    filename = (
        f"medicine_{medicine_id}_"
        f"{timestamp}.jpg"
    )

    filepath = os.path.join(
        app.config["UPLOAD_FOLDER"],
        filename
    )

    # Lưu ảnh
    photo.save(filepath)

    # Lưu tên ảnh vào database
    save_proof(
        medicine_id,
        filename
    )

    return jsonify({
        "success": True,
        "message": "Đã xác minh uống thuốc."
    })


# =========================
# CHẠY SERVER
# =========================

if __name__ == "__main__":

    app.run(
        debug=True
    )