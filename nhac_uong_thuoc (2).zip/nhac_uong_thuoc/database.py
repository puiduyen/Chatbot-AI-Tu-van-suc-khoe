import sqlite3
from datetime import datetime

DATABASE = "medicine.db"


# =========================
# KẾT NỐI DATABASE
# =========================

def get_connection():
    conn = sqlite3.connect(DATABASE)
    conn.row_factory = sqlite3.Row
    return conn


# =========================
# TẠO DATABASE
# =========================

def create_database():

    conn = get_connection()
    cursor = conn.cursor()

    cursor.execute("""
        CREATE TABLE IF NOT EXISTS medicines (
            id INTEGER PRIMARY KEY AUTOINCREMENT,
            name TEXT NOT NULL,
            time TEXT NOT NULL,
            frequency TEXT NOT NULL,
            start_date TEXT,
            end_date TEXT,
            proof TEXT DEFAULT ''
        )
    """)

    # Kiểm tra các cột cũ
    cursor.execute("PRAGMA table_info(medicines)")
    columns = [row[1] for row in cursor.fetchall()]

    # Nếu database cũ chưa có cột thì tự thêm
    if "start_date" not in columns:
        cursor.execute(
            "ALTER TABLE medicines ADD COLUMN start_date TEXT"
        )

    if "end_date" not in columns:
        cursor.execute(
            "ALTER TABLE medicines ADD COLUMN end_date TEXT"
        )

    if "proof" not in columns:
        cursor.execute(
            "ALTER TABLE medicines ADD COLUMN proof TEXT DEFAULT ''"
        )

    conn.commit()
    conn.close()


# =========================
# THÊM THUỐC
# =========================

def add_medicine(name, time, frequency, start_date, end_date):

    conn = get_connection()
    cursor = conn.cursor()

    cursor.execute("""
        INSERT INTO medicines
        (name, time, frequency, start_date, end_date, proof)
        VALUES (?, ?, ?, ?, ?, '')
    """, (
        name,
        time,
        frequency,
        start_date,
        end_date
    ))

    conn.commit()
    conn.close()


# =========================
# LẤY TẤT CẢ THUỐC
# =========================

def get_medicines():

    conn = get_connection()

    cursor = conn.cursor()

    cursor.execute("""
        SELECT *
        FROM medicines
        ORDER BY start_date, time
    """)

    medicines = cursor.fetchall()

    conn.close()

    return medicines


# =========================
# LẤY THUỐC ĐẾN GIỜ
# =========================

def get_due_medicines():

    now = datetime.now()

    today = now.strftime("%Y-%m-%d")
    current_time = now.strftime("%H:%M")

    conn = get_connection()
    cursor = conn.cursor()

    cursor.execute("""
        SELECT *
        FROM medicines
        WHERE time = ?
        AND (
            start_date IS NULL
            OR start_date = ''
            OR start_date <= ?
        )
        AND (
            end_date IS NULL
            OR end_date = ''
            OR end_date >= ?
        )
    """, (
        current_time,
        today,
        today
    ))

    medicines = cursor.fetchall()

    conn.close()

    return medicines


# =========================
# LƯU ẢNH XÁC MINH
# =========================

def save_proof(medicine_id, filename):

    conn = get_connection()
    cursor = conn.cursor()

    cursor.execute("""
        UPDATE medicines
        SET proof = ?
        WHERE id = ?
    """, (
        filename,
        medicine_id
    ))

    conn.commit()
    conn.close()


# =========================
# LẤY THUỐC THEO ID
# =========================

def get_medicine(medicine_id):

    conn = get_connection()
    cursor = conn.cursor()

    cursor.execute("""
        SELECT *
        FROM medicines
        WHERE id = ?
    """, (medicine_id,))

    medicine = cursor.fetchone()

    conn.close()

    return medicine